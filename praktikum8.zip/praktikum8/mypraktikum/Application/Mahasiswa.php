<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {
    public function index(){
        $this->load->model('Mahasiswa_model','mahasiswa');
        $list_mhs = $this->mahasiswa->getAll();

        $data['list_mahasiswa']=$list_mhs;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('mahasiswa/index',$data);
        $this->load->view('layout/footer');
        
    }

    public function create(){
        $data['judul']='Form Kelola Mahasiswa';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('mahasiswa/create',$data);
        $this->load->view('layout/footer');
    }
    
    public function save(){
        $this->load->model('mahasiswa_model','mhs1');
        $this->mhs1->id=20027;
        $this->mhs1->nama="Maydhatul As- syifa Putri Hermawan";
        $this->mhs1->gender="P";
        $this->mhs1->ipk=3.95;

        $this->load->model('mahasiswa_model','mhs2');
        $this->mhs2->id=20028;
        $this->mhs2->nama="Iqbaal Ramadhan";
        $this->mhs2->gender="L";
        $this->mhs2->ipk=4.25;

        $this->load->model('mahasiswa_model','mhs3');
        $this->mhs3->id = $this->input->post('nim');
        $this->mhs3->nama = $this->input->post('nama');
        $this->mhs3->gender = $this->input->post('gender');
        $this->mhs3->tmp_lahir = $this->input->post('tmp_lahir');
        $this->mhs3->tgl_lahir = $this->input->post('tgl_lahir');
        $this->mhs3->prodi = $this->input->post('prodi');
        $this->mhs3->ipk = $this->input->post('ipk');

        $list_mahas = [$this->mhs1,$this->mhs2,$this->mhs3];

        $data['mhs3']=$this->mhs3;
        $data['list_mhs']=$list_mahas;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('mahasiswa/view',$data);
        $this->load->view('layout/footer');
    }
}